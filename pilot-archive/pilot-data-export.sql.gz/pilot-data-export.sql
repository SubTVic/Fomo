--
-- PostgreSQL database dump
--

\restrict QFSkmuQX5c1gWB3awYkzQrWGkWoU3f2hHgwanaPaFgngJcoQERwrgCW6u8kZO3N

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: group_pilot_answers; Type: TABLE DATA; Schema: public; Owner: fomo
--



--
-- Data for Name: pilot_sessions; Type: TABLE DATA; Schema: public; Owner: fomo
--

INSERT INTO public.pilot_sessions VALUES ('cmmxndlt60000ijpec73m32g8', 'mixed', '2026-03-19 15:51:11.275', '2026-03-19 15:51:11.272', '6+', 'was', 'AIESEC in Dresden', NULL, NULL, NULL, 'chat', '["chat","classic","swipe","scroll"]');
INSERT INTO public.pilot_sessions VALUES ('cmnii2xq70000ijr96s7sui03', 'mixed', '2026-04-03 06:06:05.119', '2026-04-03 06:06:05.115', '1', 'yes', 'AEGEE-Dresden e.V.', NULL, NULL, NULL, 'swipe', '["scroll","swipe","chat","classic"]');
INSERT INTO public.pilot_sessions VALUES ('cmnkrop710000a13lsz384zwo', 'mixed', '2026-04-04 20:10:29.389', '2026-04-04 20:10:29.381', '2', 'yes', 'AIAS Dresden e.V.', NULL, NULL, NULL, 'scroll', '["chat","classic","swipe","scroll"]');
INSERT INTO public.pilot_sessions VALUES ('cmnks4oor0000a1mgz70glpkv', 'mixed', '2026-04-04 20:22:55.227', '2026-04-04 20:22:55.219', '6+', 'yes', 'AIAS Dresden e.V.', NULL, NULL, NULL, 'chat', '["swipe","chat","scroll","classic"]');


--
-- Data for Name: pilot_answers; Type: TABLE DATA; Schema: public; Owner: fomo
--

INSERT INTO public.pilot_answers VALUES ('cmmxndlt80001ijpe8kotszcc', 'cmmxndlt60000ijpec73m32g8', 'D1Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80002ijpezv14jhs2', 'cmmxndlt60000ijpec73m32g8', 'D1Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80003ijpeu3dfd6n6', 'cmmxndlt60000ijpec73m32g8', 'D1Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80004ijpe06le62uq', 'cmmxndlt60000ijpec73m32g8', 'D1Q4', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80005ijpefd07cdmd', 'cmmxndlt60000ijpec73m32g8', 'D1Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80006ijpeh8j3yq4g', 'cmmxndlt60000ijpec73m32g8', 'D1Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80007ijpeoe2lpt1b', 'cmmxndlt60000ijpec73m32g8', 'D2Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80008ijpepi57gfol', 'cmmxndlt60000ijpec73m32g8', 'D2Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80009ijpebt0vb5w2', 'cmmxndlt60000ijpec73m32g8', 'D2Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000aijpebhrgia0z', 'cmmxndlt60000ijpec73m32g8', 'D2Q4', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000bijpel2pwr7tg', 'cmmxndlt60000ijpec73m32g8', 'D2Q5', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000cijpeqoa4mrkv', 'cmmxndlt60000ijpec73m32g8', 'D2Q6', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000dijpexehbf33r', 'cmmxndlt60000ijpec73m32g8', 'D3Q1', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000eijpept13sjf5', 'cmmxndlt60000ijpec73m32g8', 'D3Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000fijpeijtlnn08', 'cmmxndlt60000ijpec73m32g8', 'D3Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000gijpe3mjueprd', 'cmmxndlt60000ijpec73m32g8', 'D3Q4', '0');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000hijpee0jpgx2h', 'cmmxndlt60000ijpec73m32g8', 'D3Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000iijpeo0ke9arj', 'cmmxndlt60000ijpec73m32g8', 'D3Q6', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000jijpemt0urxfj', 'cmmxndlt60000ijpec73m32g8', 'D4Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000kijpe1q8zd0si', 'cmmxndlt60000ijpec73m32g8', 'D4Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000lijpegsbudwcs', 'cmmxndlt60000ijpec73m32g8', 'D4Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000mijpehpbihp1q', 'cmmxndlt60000ijpec73m32g8', 'D4Q4', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000nijpe95xslb29', 'cmmxndlt60000ijpec73m32g8', 'D4Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000oijpegrvq9uhj', 'cmmxndlt60000ijpec73m32g8', 'D4Q6', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000pijpebafxplct', 'cmmxndlt60000ijpec73m32g8', 'D5Q1', '1');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000qijpeojwjyqt4', 'cmmxndlt60000ijpec73m32g8', 'D5Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000rijpe7vl6u7pe', 'cmmxndlt60000ijpec73m32g8', 'D5Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000sijpe5x2lu42s', 'cmmxndlt60000ijpec73m32g8', 'D5Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000tijpebximhadi', 'cmmxndlt60000ijpec73m32g8', 'D5Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000uijpehghf878z', 'cmmxndlt60000ijpec73m32g8', 'D6Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000vijpezv1res0k', 'cmmxndlt60000ijpec73m32g8', 'D6Q2', '1');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000wijpe4qcnqb7s', 'cmmxndlt60000ijpec73m32g8', 'D6Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000xijpel5q9aqtv', 'cmmxndlt60000ijpec73m32g8', 'D6Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000yijpe997jpqrl', 'cmmxndlt60000ijpec73m32g8', 'D6Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8000zijpeovx7qr40', 'cmmxndlt60000ijpec73m32g8', 'D6Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80010ijpe6hxy0z5d', 'cmmxndlt60000ijpec73m32g8', 'D7Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80011ijpea1tctkco', 'cmmxndlt60000ijpec73m32g8', 'D7Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80012ijpeokv5h93t', 'cmmxndlt60000ijpec73m32g8', 'D7Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80013ijpeq5x94ewo', 'cmmxndlt60000ijpec73m32g8', 'D7Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80014ijpede9ucv81', 'cmmxndlt60000ijpec73m32g8', 'D7Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80015ijpe97k1i6uj', 'cmmxndlt60000ijpec73m32g8', 'D7Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80016ijpeu10ot4b3', 'cmmxndlt60000ijpec73m32g8', 'D8Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80017ijpe2e0apuum', 'cmmxndlt60000ijpec73m32g8', 'D8Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80018ijpeiixupufc', 'cmmxndlt60000ijpec73m32g8', 'D8Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt80019ijpe0e888ilv', 'cmmxndlt60000ijpec73m32g8', 'D8Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001aijpesfgygi1w', 'cmmxndlt60000ijpec73m32g8', 'D8Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001bijpekjt0hwfw', 'cmmxndlt60000ijpec73m32g8', 'D8Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001cijpe4atf5xk1', 'cmmxndlt60000ijpec73m32g8', 'D9Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001dijpedzhl2non', 'cmmxndlt60000ijpec73m32g8', 'D9Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001eijpe5j7yyx10', 'cmmxndlt60000ijpec73m32g8', 'D9Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001fijpevdz21nwr', 'cmmxndlt60000ijpec73m32g8', 'D9Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001gijpe3lu0fa6b', 'cmmxndlt60000ijpec73m32g8', 'D9Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001hijpey29v8mzb', 'cmmxndlt60000ijpec73m32g8', 'D10Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001iijpeylenxzdx', 'cmmxndlt60000ijpec73m32g8', 'D10Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001jijpe8wftw94j', 'cmmxndlt60000ijpec73m32g8', 'D10Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmmxndlt8001kijpe4kcdykbc', 'cmmxndlt60000ijpec73m32g8', 'D10Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80001ijr9hzlipt4z', 'cmnii2xq70000ijr96s7sui03', 'D1Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80002ijr9pte5tupm', 'cmnii2xq70000ijr96s7sui03', 'D1Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80003ijr9wettwnwm', 'cmnii2xq70000ijr96s7sui03', 'D1Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80004ijr9k5xiycqf', 'cmnii2xq70000ijr96s7sui03', 'D1Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80005ijr9h2xk2x7l', 'cmnii2xq70000ijr96s7sui03', 'D1Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80006ijr9hb5lfdt1', 'cmnii2xq70000ijr96s7sui03', 'D1Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80007ijr9qi5i8hqh', 'cmnii2xq70000ijr96s7sui03', 'D2Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80008ijr9wwztixva', 'cmnii2xq70000ijr96s7sui03', 'D2Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80009ijr9ryz52q5z', 'cmnii2xq70000ijr96s7sui03', 'D2Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000aijr9ofyscomn', 'cmnii2xq70000ijr96s7sui03', 'D2Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000bijr9bi757glr', 'cmnii2xq70000ijr96s7sui03', 'D2Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000cijr9nrdemyyc', 'cmnii2xq70000ijr96s7sui03', 'D2Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000dijr98en0p8jk', 'cmnii2xq70000ijr96s7sui03', 'D3Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000eijr9ugg2a05b', 'cmnii2xq70000ijr96s7sui03', 'D3Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000fijr9uyrj2lm9', 'cmnii2xq70000ijr96s7sui03', 'D3Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000gijr91saao2d5', 'cmnii2xq70000ijr96s7sui03', 'D3Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000hijr9azmcuiqt', 'cmnii2xq70000ijr96s7sui03', 'D3Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000iijr9e7hnngca', 'cmnii2xq70000ijr96s7sui03', 'D3Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000jijr9fs52pjh2', 'cmnii2xq70000ijr96s7sui03', 'D4Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000kijr9rzldib13', 'cmnii2xq70000ijr96s7sui03', 'D4Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000lijr9ea4256jp', 'cmnii2xq70000ijr96s7sui03', 'D4Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000mijr9n07bgppw', 'cmnii2xq70000ijr96s7sui03', 'D4Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000nijr9tky4h9ol', 'cmnii2xq70000ijr96s7sui03', 'D4Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000oijr9a0rmiqme', 'cmnii2xq70000ijr96s7sui03', 'D4Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000pijr9kfc96fby', 'cmnii2xq70000ijr96s7sui03', 'D5Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000qijr9220v3lw6', 'cmnii2xq70000ijr96s7sui03', 'D5Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000rijr92fqwqfyt', 'cmnii2xq70000ijr96s7sui03', 'D5Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000sijr95z7hnfww', 'cmnii2xq70000ijr96s7sui03', 'D5Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000tijr9hnfnhw7g', 'cmnii2xq70000ijr96s7sui03', 'D5Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000uijr9ik4wtu73', 'cmnii2xq70000ijr96s7sui03', 'D6Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000vijr9bevn2pxd', 'cmnii2xq70000ijr96s7sui03', 'D6Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000wijr9633im2d8', 'cmnii2xq70000ijr96s7sui03', 'D6Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000xijr946na86ej', 'cmnii2xq70000ijr96s7sui03', 'D6Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000yijr93kofgz9r', 'cmnii2xq70000ijr96s7sui03', 'D6Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8000zijr9ce3by56l', 'cmnii2xq70000ijr96s7sui03', 'D6Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80010ijr97y3998ah', 'cmnii2xq70000ijr96s7sui03', 'D7Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80011ijr93b37axp8', 'cmnii2xq70000ijr96s7sui03', 'D7Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80012ijr98rsms718', 'cmnii2xq70000ijr96s7sui03', 'D7Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80013ijr95eobrwjo', 'cmnii2xq70000ijr96s7sui03', 'D7Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80014ijr9c7964c66', 'cmnii2xq70000ijr96s7sui03', 'D7Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80015ijr94utb8p9b', 'cmnii2xq70000ijr96s7sui03', 'D7Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80016ijr9u2cdyivy', 'cmnii2xq70000ijr96s7sui03', 'D8Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80017ijr9ms91p1nx', 'cmnii2xq70000ijr96s7sui03', 'D8Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80018ijr9lowfhx4e', 'cmnii2xq70000ijr96s7sui03', 'D8Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq80019ijr9uv4tw95d', 'cmnii2xq70000ijr96s7sui03', 'D8Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001aijr9nz1m4fvl', 'cmnii2xq70000ijr96s7sui03', 'D8Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001bijr96sjgicd6', 'cmnii2xq70000ijr96s7sui03', 'D8Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001cijr9x1iqjeqf', 'cmnii2xq70000ijr96s7sui03', 'D9Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001dijr9mfakxz8t', 'cmnii2xq70000ijr96s7sui03', 'D9Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001eijr9jzaz14ho', 'cmnii2xq70000ijr96s7sui03', 'D9Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001fijr96seua21d', 'cmnii2xq70000ijr96s7sui03', 'D9Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001gijr9q0lh23r6', 'cmnii2xq70000ijr96s7sui03', 'D9Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001hijr9gk8lutf6', 'cmnii2xq70000ijr96s7sui03', 'D10Q1', '3');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001iijr9hzjxylng', 'cmnii2xq70000ijr96s7sui03', 'D10Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001jijr96kipzzwi', 'cmnii2xq70000ijr96s7sui03', 'D10Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001kijr984z071w9', 'cmnii2xq70000ijr96s7sui03', 'D10Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnii2xq8001lijr95g33br09', 'cmnii2xq70000ijr96s7sui03', 'q63_priming_check', 'partial');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720001a13lsc8jlckl', 'cmnkrop710000a13lsz384zwo', 'D1Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720002a13lzcj8at9y', 'cmnkrop710000a13lsz384zwo', 'D1Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720003a13ljwavs7jw', 'cmnkrop710000a13lsz384zwo', 'D1Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720004a13ly3sfugxh', 'cmnkrop710000a13lsz384zwo', 'D1Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720005a13led5ia5b7', 'cmnkrop710000a13lsz384zwo', 'D1Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720006a13lunj4svuo', 'cmnkrop710000a13lsz384zwo', 'D1Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720007a13luwsxr6as', 'cmnkrop710000a13lsz384zwo', 'D2Q1', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720008a13lpwbfns7a', 'cmnkrop710000a13lsz384zwo', 'D2Q2', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop720009a13lcldqzdno', 'cmnkrop710000a13lsz384zwo', 'D2Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop72000aa13lemsk8efz', 'cmnkrop710000a13lsz384zwo', 'D2Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ba13lbctfyt3j', 'cmnkrop710000a13lsz384zwo', 'D2Q5', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ca13lhgik1t8f', 'cmnkrop710000a13lsz384zwo', 'D2Q6', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000da13lr5jis1fc', 'cmnkrop710000a13lsz384zwo', 'D3Q1', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ea13l6blw79o2', 'cmnkrop710000a13lsz384zwo', 'D3Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000fa13l153dnlyf', 'cmnkrop710000a13lsz384zwo', 'D3Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ga13l33hvv1gk', 'cmnkrop710000a13lsz384zwo', 'D3Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ha13laur8kmmb', 'cmnkrop710000a13lsz384zwo', 'D3Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ia13l0xdjxy1k', 'cmnkrop710000a13lsz384zwo', 'D3Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ja13ldjh5cspk', 'cmnkrop710000a13lsz384zwo', 'D4Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ka13loxl5mqdg', 'cmnkrop710000a13lsz384zwo', 'D4Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000la13lqgk0aj5s', 'cmnkrop710000a13lsz384zwo', 'D4Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ma13lzh9azyxa', 'cmnkrop710000a13lsz384zwo', 'D4Q4', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000na13lc9q51s7t', 'cmnkrop710000a13lsz384zwo', 'D4Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000oa13l2khbt4xt', 'cmnkrop710000a13lsz384zwo', 'D4Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000pa13l6iteo567', 'cmnkrop710000a13lsz384zwo', 'D5Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000qa13l7yr2o8ts', 'cmnkrop710000a13lsz384zwo', 'D5Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ra13l3diy3au8', 'cmnkrop710000a13lsz384zwo', 'D5Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000sa13lt7a089h3', 'cmnkrop710000a13lsz384zwo', 'D5Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ta13lm3fdh43r', 'cmnkrop710000a13lsz384zwo', 'D6Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ua13l5pm1e169', 'cmnkrop710000a13lsz384zwo', 'D6Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000va13la1tqjd4m', 'cmnkrop710000a13lsz384zwo', 'D6Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000wa13lom0lydha', 'cmnkrop710000a13lsz384zwo', 'D6Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000xa13lo6doy6yl', 'cmnkrop710000a13lsz384zwo', 'D6Q5', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000ya13lhqi6p8x2', 'cmnkrop710000a13lsz384zwo', 'D6Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73000za13l2l64twwy', 'cmnkrop710000a13lsz384zwo', 'D7Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730010a13labse0ap8', 'cmnkrop710000a13lsz384zwo', 'D7Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730011a13lb9ux39zq', 'cmnkrop710000a13lsz384zwo', 'D7Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730012a13ll1vxy29x', 'cmnkrop710000a13lsz384zwo', 'D7Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730013a13lsvciybv9', 'cmnkrop710000a13lsz384zwo', 'D7Q5', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730014a13lwv2zftfo', 'cmnkrop710000a13lsz384zwo', 'D7Q6', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730015a13lagfatt4j', 'cmnkrop710000a13lsz384zwo', 'D8Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730016a13l9af2qlvt', 'cmnkrop710000a13lsz384zwo', 'D8Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730017a13lig3uqnwe', 'cmnkrop710000a13lsz384zwo', 'D8Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730018a13l2fsq8oiy', 'cmnkrop710000a13lsz384zwo', 'D8Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop730019a13lydfyvl9v', 'cmnkrop710000a13lsz384zwo', 'D8Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001aa13lyjwzbio3', 'cmnkrop710000a13lsz384zwo', 'D8Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ba13lj588axz3', 'cmnkrop710000a13lsz384zwo', 'D9Q1', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ca13l40isonmc', 'cmnkrop710000a13lsz384zwo', 'D9Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001da13luqhyna50', 'cmnkrop710000a13lsz384zwo', 'D9Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ea13l4ahfwfyn', 'cmnkrop710000a13lsz384zwo', 'D9Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001fa13l6qjjofcw', 'cmnkrop710000a13lsz384zwo', 'D9Q5', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ga13liavhcii3', 'cmnkrop710000a13lsz384zwo', 'D10Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ha13ly0t0txff', 'cmnkrop710000a13lsz384zwo', 'D10Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ia13le9zmqlqx', 'cmnkrop710000a13lsz384zwo', 'D10Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ja13l45hvbvgg', 'cmnkrop710000a13lsz384zwo', 'D10Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ka13ll9roc7ya', 'cmnkrop710000a13lsz384zwo', 'S1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001la13lb2a45wcl', 'cmnkrop710000a13lsz384zwo', 'S2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001ma13lahxmv2mv', 'cmnkrop710000a13lsz384zwo', 'S3', '1');
INSERT INTO public.pilot_answers VALUES ('cmnkrop73001na13lpm7rhpm7', 'cmnkrop710000a13lsz384zwo', 'q63_priming_check', 'partial');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0001a1mg4fv0ro53', 'cmnks4oor0000a1mgz70glpkv', 'D1Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0002a1mgisyv4gcp', 'cmnks4oor0000a1mgz70glpkv', 'D1Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0003a1mg2yeh7uja', 'cmnks4oor0000a1mgz70glpkv', 'D1Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0004a1mgp5utp61m', 'cmnks4oor0000a1mgz70glpkv', 'D1Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0005a1mga1t0i5c8', 'cmnks4oor0000a1mgz70glpkv', 'D1Q5', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0006a1mgvgy8znej', 'cmnks4oor0000a1mgz70glpkv', 'D1Q6', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0007a1mgkgyeb3ro', 'cmnks4oor0000a1mgz70glpkv', 'D2Q1', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0008a1mgw23wz9ps', 'cmnks4oor0000a1mgz70glpkv', 'D2Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0009a1mg1u3it4fs', 'cmnks4oor0000a1mgz70glpkv', 'D2Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000aa1mgmljs5mca', 'cmnks4oor0000a1mgz70glpkv', 'D2Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ba1mgdsf22mhh', 'cmnks4oor0000a1mgz70glpkv', 'D2Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ca1mghdi3l2l3', 'cmnks4oor0000a1mgz70glpkv', 'D2Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000da1mgcmquf0i9', 'cmnks4oor0000a1mgz70glpkv', 'D3Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ea1mgs09xawog', 'cmnks4oor0000a1mgz70glpkv', 'D3Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000fa1mgmup0wrx1', 'cmnks4oor0000a1mgz70glpkv', 'D3Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ga1mgwjnx8ne1', 'cmnks4oor0000a1mgz70glpkv', 'D3Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ha1mgo1iysktx', 'cmnks4oor0000a1mgz70glpkv', 'D3Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ia1mg4akofs0k', 'cmnks4oor0000a1mgz70glpkv', 'D3Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ja1mg55q5k7cq', 'cmnks4oor0000a1mgz70glpkv', 'D4Q1', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ka1mg3f4w22sx', 'cmnks4oor0000a1mgz70glpkv', 'D4Q2', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000la1mgux07d9f4', 'cmnks4oor0000a1mgz70glpkv', 'D4Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ma1mgyta0n3ra', 'cmnks4oor0000a1mgz70glpkv', 'D4Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000na1mgqdt00m3o', 'cmnks4oor0000a1mgz70glpkv', 'D4Q5', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000oa1mgsb7bt3aj', 'cmnks4oor0000a1mgz70glpkv', 'D4Q6', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000pa1mgh06t5oqk', 'cmnks4oor0000a1mgz70glpkv', 'D5Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000qa1mgv1pjh8iy', 'cmnks4oor0000a1mgz70glpkv', 'D5Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ra1mgumm32cb4', 'cmnks4oor0000a1mgz70glpkv', 'D5Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000sa1mgx7vfekkq', 'cmnks4oor0000a1mgz70glpkv', 'D5Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ta1mg1ogjhs77', 'cmnks4oor0000a1mgz70glpkv', 'D5Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ua1mgcnx63rrv', 'cmnks4oor0000a1mgz70glpkv', 'D6Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000va1mgtlr9ok9r', 'cmnks4oor0000a1mgz70glpkv', 'D6Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000wa1mgtkjk8lcf', 'cmnks4oor0000a1mgz70glpkv', 'D6Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000xa1mg08y8jm7k', 'cmnks4oor0000a1mgz70glpkv', 'D6Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000ya1mgp7whaiwk', 'cmnks4oor0000a1mgz70glpkv', 'D6Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos000za1mg01bx92zv', 'cmnks4oor0000a1mgz70glpkv', 'D6Q6', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0010a1mgqumqq0ip', 'cmnks4oor0000a1mgz70glpkv', 'D7Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0011a1mgcu81nax4', 'cmnks4oor0000a1mgz70glpkv', 'D7Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0012a1mg999aaw8x', 'cmnks4oor0000a1mgz70glpkv', 'D7Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0013a1mguxtpmbua', 'cmnks4oor0000a1mgz70glpkv', 'D7Q4', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0014a1mgnt4d9vcs', 'cmnks4oor0000a1mgz70glpkv', 'D7Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0015a1mgilmux783', 'cmnks4oor0000a1mgz70glpkv', 'D7Q6', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0016a1mgqntkj3hz', 'cmnks4oor0000a1mgz70glpkv', 'D8Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0017a1mg0wwqwjl2', 'cmnks4oor0000a1mgz70glpkv', 'D8Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0018a1mgcdju8xq1', 'cmnks4oor0000a1mgz70glpkv', 'D8Q3', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos0019a1mgzscutmtf', 'cmnks4oor0000a1mgz70glpkv', 'D8Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001aa1mg9euwn68l', 'cmnks4oor0000a1mgz70glpkv', 'D8Q5', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ba1mgq1nq8jbf', 'cmnks4oor0000a1mgz70glpkv', 'D8Q6', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ca1mg9mzhxrti', 'cmnks4oor0000a1mgz70glpkv', 'D9Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001da1mgx6xlxkbx', 'cmnks4oor0000a1mgz70glpkv', 'D9Q2', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ea1mgw5f0ain1', 'cmnks4oor0000a1mgz70glpkv', 'D9Q3', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001fa1mg4anusl2c', 'cmnks4oor0000a1mgz70glpkv', 'D9Q4', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ga1mgiu16rs0z', 'cmnks4oor0000a1mgz70glpkv', 'D9Q5', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ha1mgr0ei7jvt', 'cmnks4oor0000a1mgz70glpkv', 'D10Q1', '5');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ia1mg8zjowe1n', 'cmnks4oor0000a1mgz70glpkv', 'D10Q2', '3');
INSERT INTO public.pilot_answers VALUES ('cmnks4oos001ja1mg5hsqg977', 'cmnks4oor0000a1mgz70glpkv', 'D10Q3', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oot001ka1mg2ii5pv90', 'cmnks4oor0000a1mgz70glpkv', 'D10Q4', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oot001la1mggmjlaljq', 'cmnks4oor0000a1mgz70glpkv', 'S1', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oot001ma1mg6ilvre6v', 'cmnks4oor0000a1mgz70glpkv', 'S2', '1');
INSERT INTO public.pilot_answers VALUES ('cmnks4oot001na1mgte34yee4', 'cmnks4oor0000a1mgz70glpkv', 'S3', '3');


--
-- Data for Name: pilot_dimensions; Type: TABLE DATA; Schema: public; Owner: fomo
--

INSERT INTO public.pilot_dimensions VALUES ('D1', 'Zeitbudget & Verbindlichkeit', '⏰', 'Wie viel Zeit und Verbindlichkeit möchtest du einbringen?', 0, 1, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268');
INSERT INTO public.pilot_dimensions VALUES ('D2', 'Hands-on vs. Theoretisch', '🔨', 'Praktisch anpacken oder konzeptionell denken – was liegt dir mehr?', 0, 2, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274');
INSERT INTO public.pilot_dimensions VALUES ('D3', 'Geselligkeit & Gemeinschaft', '👥', 'Suchst du vor allem Gemeinschaft und Spaß, oder geht es dir um die Sache?', 0, 3, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277');
INSERT INTO public.pilot_dimensions VALUES ('D4', 'Politisches Engagement', '📢', 'Wie wichtig ist dir gesellschaftliches oder politisches Engagement?', 1, 4, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28');
INSERT INTO public.pilot_dimensions VALUES ('D5', 'Kreativität', '🎨', 'Spielen kreative Projekte und künstlerischer Ausdruck eine Rolle?', 1, 5, '2026-03-19 19:27:48.283', '2026-03-19 19:27:48.283');
INSERT INTO public.pilot_dimensions VALUES ('D6', 'Werte & Weltanschauung', '🌱', 'Sollen gemeinsame Werte oder eine Weltanschauung die Gruppe prägen?', 2, 6, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285');
INSERT INTO public.pilot_dimensions VALUES ('D7', 'Internationalität', '🌍', 'Wie wichtig ist dir internationaler Austausch und Diversität?', 2, 7, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288');
INSERT INTO public.pilot_dimensions VALUES ('D8', 'Kompetitivität', '🏆', 'Motivieren dich Wettbewerbe, Ranglistenplätze und messbare Leistung?', 2, 8, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291');
INSERT INTO public.pilot_dimensions VALUES ('D9', 'Digital vs. Analog', '💻', 'Arbeitest du lieber mit digitalen Tools oder analog vor Ort?', 3, 9, '2026-03-19 19:27:48.293', '2026-03-19 19:27:48.293');
INSERT INTO public.pilot_dimensions VALUES ('D10', 'Einstiegsfreundlichkeit', '🚀', 'Wie wichtig ist dir ein niedrigschwelliger, anfängerfreundlicher Einstieg?', 3, 10, '2026-03-19 19:27:48.295', '2026-03-19 19:27:48.295');


--
-- Data for Name: pilot_survey_questions; Type: TABLE DATA; Schema: public; Owner: fomo
--

INSERT INTO public.pilot_survey_questions VALUES ('D1Q1', 'D1', 'Ich bin bereit, mehr als 5 Stunden pro Woche für eine Hochschulgruppe zu investieren.', 1, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268', false);
INSERT INTO public.pilot_survey_questions VALUES ('D1Q2', 'D1', 'Ich möchte mich langfristig (mindestens 2 Semester) in einer Gruppe engagieren.', 2, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268', false);
INSERT INTO public.pilot_survey_questions VALUES ('D1Q3', 'D1', 'Feste, regelmäßige Treffen (z.B. wöchentlich) sind mir wichtig.', 3, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268', false);
INSERT INTO public.pilot_survey_questions VALUES ('D1Q4', 'D1', 'Ich bin bereit, auch abends oder am Wochenende Zeit für Gruppenaktivitäten einzuplanen.', 4, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268', false);
INSERT INTO public.pilot_survey_questions VALUES ('D1Q5', 'D1', 'Ich möchte eine Gruppe, in der Mitglieder auch zwischen den Treffen Aufgaben übernehmen.', 5, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268', false);
INSERT INTO public.pilot_survey_questions VALUES ('D1Q6', 'D1', 'Ein intensives, verbindliches Engagement ist mir lieber als eine lockere Mitgliedschaft.', 6, '2026-03-19 19:27:48.268', '2026-03-19 19:27:48.268', false);
INSERT INTO public.pilot_survey_questions VALUES ('D2Q1', 'D2', 'Ich lerne lieber durch praktisches Tun als durch Theorie und Diskussion.', 1, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274', false);
INSERT INTO public.pilot_survey_questions VALUES ('D2Q2', 'D2', 'Ich verstehe neue Dinge am besten, wenn ich sie selbst ausprobiere.', 2, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274', false);
INSERT INTO public.pilot_survey_questions VALUES ('D2Q3', 'D2', 'Ich bin gerne im Labor, in der Werkstatt oder direkt im Feld aktiv.', 3, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274', false);
INSERT INTO public.pilot_survey_questions VALUES ('D2Q4', 'D2', 'Ich möchte handwerkliche, technische oder gestalterische Fähigkeiten in der Gruppe einsetzen.', 4, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274', false);
INSERT INTO public.pilot_survey_questions VALUES ('D2Q5', 'D2', 'Ich beschäftige mich lieber mit Diskussionen und Konzepten als mit praktischer Umsetzung.', 5, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274', true);
INSERT INTO public.pilot_survey_questions VALUES ('D2Q6', 'D2', 'Ich lese und recherchiere lieber über ein Thema, als selbst etwas umzusetzen.', 6, '2026-03-19 19:27:48.274', '2026-03-19 19:27:48.274', true);
INSERT INTO public.pilot_survey_questions VALUES ('D3Q1', 'D3', 'Gemeinsame Freizeitaktivitäten (z.B. Feiern oder Ausflüge) sind mir in einer Gruppe wichtig.', 1, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277', false);
INSERT INTO public.pilot_survey_questions VALUES ('D3Q2', 'D3', 'Wenn ich die Wahl hätte, würde ich lieber einen gemütlichen Gruppenabend verbringen als an einem Projekt zu arbeiten.', 2, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277', false);
INSERT INTO public.pilot_survey_questions VALUES ('D3Q3', 'D3', 'In einer Hochschulgruppe suche ich vor allem neue soziale Kontakte.', 3, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277', false);
INSERT INTO public.pilot_survey_questions VALUES ('D3Q4', 'D3', 'Eine gute Gruppe unternimmt regelmäßig etwas gemeinsam außerhalb der eigentlichen Projekte.', 4, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277', false);
INSERT INTO public.pilot_survey_questions VALUES ('D3Q5', 'D3', 'Mir ist das Thema der Gruppe wichtiger als die anderen Mitglieder und das Gemeinschaftsgefühl.', 5, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277', true);
INSERT INTO public.pilot_survey_questions VALUES ('D3Q6', 'D3', 'Ich würde in einer Gruppe bleiben, wenn ich mich mit den Mitgliedern gut verstehe, auch wenn mich das Thema weniger interessiert.', 6, '2026-03-19 19:27:48.277', '2026-03-19 19:27:48.277', false);
INSERT INTO public.pilot_survey_questions VALUES ('D4Q1', 'D4', 'Ich möchte gesellschaftlichen Wandel aktiv mitgestalten.', 1, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28', false);
INSERT INTO public.pilot_survey_questions VALUES ('D4Q2', 'D4', 'Politisches oder soziales Engagement ist ein wichtiger Teil meines Studiums für mich.', 2, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28', false);
INSERT INTO public.pilot_survey_questions VALUES ('D4Q3', 'D4', 'Ich interessiere mich für Hochschulpolitik und studentische Mitbestimmung.', 3, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28', false);
INSERT INTO public.pilot_survey_questions VALUES ('D4Q4', 'D4', 'Ich möchte, dass meine Gruppe sich öffentlich zu politischen Themen positioniert.', 4, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28', false);
INSERT INTO public.pilot_survey_questions VALUES ('D4Q5', 'D4', 'Ich kann mir vorstellen, politische Aktionen oder Kampagnen mitzuorganisieren.', 5, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28', false);
INSERT INTO public.pilot_survey_questions VALUES ('D4Q6', 'D4', 'Ich bevorzuge Gruppen, die sich nicht mit politischen oder gesellschaftlichen Themen beschäftigen.', 6, '2026-03-19 19:27:48.28', '2026-03-19 19:27:48.28', true);
INSERT INTO public.pilot_survey_questions VALUES ('D5Q1', 'D5', 'Kreatives Gestalten (z.B. Schreiben, Design, Fotografie oder Musik) ist mir wichtig.', 1, '2026-03-19 19:27:48.283', '2026-03-19 19:27:48.283', false);
INSERT INTO public.pilot_survey_questions VALUES ('D5Q2', 'D5', 'Ich möchte in einer Gruppe eigene künstlerische Projekte realisieren.', 2, '2026-03-19 19:27:48.283', '2026-03-19 19:27:48.283', false);
INSERT INTO public.pilot_survey_questions VALUES ('D5Q3', 'D5', 'Kulturelle Veranstaltungen zu organisieren oder mitzugestalten macht mir Spaß.', 3, '2026-03-19 19:27:48.283', '2026-03-19 19:27:48.283', false);
INSERT INTO public.pilot_survey_questions VALUES ('D5Q4', 'D5', 'Kreative Hobbys spielen in meiner Freizeit eine wichtige Rolle.', 4, '2026-03-19 19:27:48.283', '2026-03-19 19:27:48.283', false);
INSERT INTO public.pilot_survey_questions VALUES ('D5Q5', 'D5', 'Gestaltung und Ästhetik sind für mich wichtige Aspekte in meiner Arbeit.', 5, '2026-03-19 19:27:48.283', '2026-03-19 19:27:48.283', false);
INSERT INTO public.pilot_survey_questions VALUES ('D6Q1', 'D6', 'Mein Glaube oder meine Weltanschauung soll in der Gruppe eine sichtbare Rolle spielen.', 1, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285', false);
INSERT INTO public.pilot_survey_questions VALUES ('D6Q2', 'D6', 'Bevor ich einer Gruppe beitrete, will ich wissen, wofür sie steht und welche Werte sie vertritt.', 2, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285', false);
INSERT INTO public.pilot_survey_questions VALUES ('D6Q3', 'D6', 'Nachhaltigkeit und ökologisches Handeln sind für mich unverzichtbare Gruppenmerkmale.', 3, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285', false);
INSERT INTO public.pilot_survey_questions VALUES ('D6Q4', 'D6', 'Ich suche eine Gemeinschaft, die geteilte Werte und eine gemeinsame Identität hat.', 4, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285', false);
INSERT INTO public.pilot_survey_questions VALUES ('D6Q5', 'D6', 'Spirituelle oder philosophische Fragen beschäftigen mich und sollen Raum in der Gruppe haben.', 5, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285', false);
INSERT INTO public.pilot_survey_questions VALUES ('D6Q6', 'D6', 'Ich würde mich in einer Gruppe mit sehr unterschiedlichen Weltanschauungen unwohl fühlen.', 6, '2026-03-19 19:27:48.285', '2026-03-19 19:27:48.285', false);
INSERT INTO public.pilot_survey_questions VALUES ('D7Q1', 'D7', 'Ich möchte in der Gruppe internationale Studierende kennenlernen.', 1, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288', false);
INSERT INTO public.pilot_survey_questions VALUES ('D7Q2', 'D7', 'Ich nutze gerne Fremdsprachen in einer Hochschulgruppe.', 2, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288', false);
INSERT INTO public.pilot_survey_questions VALUES ('D7Q3', 'D7', 'Ich möchte in der Gruppe an internationalen Projekten oder Partnerschaften mitarbeiten.', 3, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288', false);
INSERT INTO public.pilot_survey_questions VALUES ('D7Q4', 'D7', 'Ich plane, ins Ausland zu gehen, und suche dort Kontakte und Netzwerke.', 4, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288', false);
INSERT INTO public.pilot_survey_questions VALUES ('D7Q5', 'D7', 'Eine Gruppe, die auch auf Englisch kommuniziert, interessiert mich.', 5, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288', false);
INSERT INTO public.pilot_survey_questions VALUES ('D7Q6', 'D7', 'Eine Gruppe, die internationale Themen bearbeitet, interessiert mich.', 6, '2026-03-19 19:27:48.288', '2026-03-19 19:27:48.288', false);
INSERT INTO public.pilot_survey_questions VALUES ('D8Q1', 'D8', 'Ich schätze Wettbewerbe und Turniere – ob Sport, Hackathon oder Debatte.', 1, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291', false);
INSERT INTO public.pilot_survey_questions VALUES ('D8Q2', 'D8', 'Klare Ziele und messbare Ergebnisse spornen mich an.', 2, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291', false);
INSERT INTO public.pilot_survey_questions VALUES ('D8Q3', 'D8', 'Ich nehme gerne an Wettbewerben oder Rankings teil.', 3, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291', false);
INSERT INTO public.pilot_survey_questions VALUES ('D8Q4', 'D8', 'Ich vergleiche meine Leistungen gerne mit anderen.', 4, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291', false);
INSERT INTO public.pilot_survey_questions VALUES ('D8Q5', 'D8', 'Ich trainiere oder übe intensiv, um ein anspruchsvolles Ziel zu erreichen.', 5, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291', false);
INSERT INTO public.pilot_survey_questions VALUES ('D8Q6', 'D8', 'Ein kompetitives Umfeld spornt mich an und bringt meine Leistung auf ein höheres Niveau.', 6, '2026-03-19 19:27:48.291', '2026-03-19 19:27:48.291', false);
INSERT INTO public.pilot_survey_questions VALUES ('D9Q1', 'D9', 'Digitale Tools, Online-Kollaboration und Remote-Arbeit bevorzuge ich gegenüber reinen Präsenztreffen.', 1, '2026-03-19 19:27:48.293', '2026-03-19 19:27:48.293', false);
INSERT INTO public.pilot_survey_questions VALUES ('D9Q2', 'D9', 'Social-Media-Präsenz und digitale Kommunikation interessieren mich.', 2, '2026-03-19 19:27:48.293', '2026-03-19 19:27:48.293', false);
INSERT INTO public.pilot_survey_questions VALUES ('D9Q3', 'D9', 'Analoge Aktivitäten – z.B. Basteln, Kochen, Outdoor-Aktionen – ziehe ich digitalen vor.', 3, '2026-03-19 19:27:48.293', '2026-03-19 19:27:48.293', true);
INSERT INTO public.pilot_survey_questions VALUES ('D9Q4', 'D9', 'Persönliche Treffen vor Ort sind mir wichtiger als Online-Zusammenarbeit.', 4, '2026-03-19 19:27:48.293', '2026-03-19 19:27:48.293', true);
INSERT INTO public.pilot_survey_questions VALUES ('D9Q5', 'D9', 'Mir wäre es recht, wenn die meisten Treffen meiner Gruppe online stattfinden.', 5, '2026-03-19 19:27:48.293', '2026-03-19 19:27:48.293', false);
INSERT INTO public.pilot_survey_questions VALUES ('D10Q1', 'D10', 'Ich bevorzuge Gruppen, bei denen man ohne Vorkenntnisse mitmachen kann.', 1, '2026-03-19 19:27:48.295', '2026-03-19 19:27:48.295', false);
INSERT INTO public.pilot_survey_questions VALUES ('D10Q2', 'D10', 'Ich komme auch gut zurecht, wenn eine Gruppe kein spezielles Einführungsprogramm hat.', 2, '2026-03-19 19:27:48.295', '2026-03-19 19:27:48.295', true);
INSERT INTO public.pilot_survey_questions VALUES ('D10Q3', 'D10', 'Es ist für mich in Ordnung, zunächst zuzuschauen, bevor ich aktiv mitmache.', 3, '2026-03-19 19:27:48.295', '2026-03-19 19:27:48.295', true);
INSERT INTO public.pilot_survey_questions VALUES ('D10Q4', 'D10', 'Mir ist wichtig, schnell und unkompliziert in eine Gruppe einsteigen zu können.', 4, '2026-03-19 19:27:48.295', '2026-03-19 19:27:48.295', false);
INSERT INTO public.pilot_survey_questions VALUES ('S1', NULL, 'Ich möchte neben dem Studium ein eigenes Projekt oder Startup aufbauen.', 1, '2026-03-19 19:27:48.297', '2026-03-19 19:27:48.297', false);
INSERT INTO public.pilot_survey_questions VALUES ('S2', NULL, 'Unternehmerisches Denken und Gründergeist begeistern mich.', 2, '2026-03-19 19:27:48.299', '2026-03-19 19:27:48.299', false);
INSERT INTO public.pilot_survey_questions VALUES ('S3', NULL, 'Ich bevorzuge kleine Gruppen mit weniger als 20 aktiven Mitgliedern.', 3, '2026-03-19 19:27:48.3', '2026-03-19 19:27:48.3', false);


--
-- PostgreSQL database dump complete
--

\unrestrict QFSkmuQX5c1gWB3awYkzQrWGkWoU3f2hHgwanaPaFgngJcoQERwrgCW6u8kZO3N

